﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class AssignEmployees : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("ShowRegularEmployees", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            // string manager = Session["Username"].ToString();
            string manager = "youssef.yasser";

            cmd.Parameters.Add(new SqlParameter("@manager", manager));

            cmd.Connection = conn;
            conn.Open();
            RegularEmployees.DataSource = cmd.ExecuteReader();
            RegularEmployees.DataTextField = "username";
            // ddlCustomers.DataValueField = "CustomerId";
            RegularEmployees.DataBind();
            conn.Close();


            RegularEmployees.Items.Insert(0, new ListItem("--Select Employee--", "0"));

        }
    }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        String temp = RegularEmployees.SelectedItem.Value;
        Session["RegularEmployee"] = temp;
      
    }

    protected void Assign(object sender, EventArgs e)
    {
        Response.Redirect("AssignEmployeesToTask", true);

    }

    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("ManagerProfile", true);
    }

    protected void Change(object sender, EventArgs e)
    {
        Response.Redirect("ChangeEmployees", true);
    }


    protected void Assign_employees(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("spAssignEmployeesToProjects", conn);
        cmd.CommandType = CommandType.StoredProcedure;





        string projectname = txt_projectname.Text;
      //  string regular = txt_RegularEmployee.Text;
       
        cmd.Parameters.Add(new SqlParameter("@projectName", projectname));
        cmd.Parameters.Add(new SqlParameter("@regularEmployee", Session["RegularEmployee"]));

        // string manager = Session["Username"].ToString();
        // string companymail = Session["companymail"].ToString();

        string manager = "youssef.yasser";
        string companymail = "main@shell.us";

        cmd.Parameters.Add(new SqlParameter("@companyMail", companymail));
        cmd.Parameters.Add(new SqlParameter("@manager", manager));

        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;



        if (projectname != "")
        {

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (error.Value.Equals(0))
            {
                Response.Write("Assigned ! ");
            }
            else
            {
                Response.Write("one of your entries are wrong ");
            }
        }
        else
        {
            Response.Write("you should enter a project name ");

        }

    }

}