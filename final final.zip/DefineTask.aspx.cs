﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


public partial class DefineTask : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Assign(object sender, EventArgs e)
    {
        Response.Redirect("AssignEmployeesToTask", true);

    }
    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("ManagerProfile", true);

    }
    protected void Define(object sender, EventArgs e)
    {

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("spDefineTask", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        string taskname = txt_TaskName.Text;
        string projectname = ProjectName.Text;
        string deadline = Deadline.Text;
        string Description = description.Text;
        cmd.Parameters.Add(new SqlParameter("@Taskname", taskname));
        cmd.Parameters.Add(new SqlParameter("@projectName", projectname));
        cmd.Parameters.Add(new SqlParameter("@deadline", deadline));
        cmd.Parameters.Add(new SqlParameter("@description", Description));

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";

        // string company = Session["Company"].ToString();
        string Company = "main@shell.us";
        cmd.Parameters.Add(new SqlParameter("@manager", username));
        cmd.Parameters.Add(new SqlParameter("@company", Company)) ;
        //SqlParameter pass = cmd.Parameters.Add("@password", SqlDbType.VarChar, 50);
        //pass.Value = password;

        // output parm
        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;

        if (projectname != "" & taskname!= "" & deadline != "" & Description!= "")
        {

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (error.Value.Equals(0))
            {
                Response.Write("Task Defined");
            }
            else
            {
                Response.Write("one of your entries are wrong ");
            }
        }
        else
        {
            Response.Write("you should fill in all the Entries ");

        }
    }
}