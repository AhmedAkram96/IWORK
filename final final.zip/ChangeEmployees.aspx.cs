﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class ChangeEmployees : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Change(object sender, EventArgs e)
    {

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("spChangeRegularEmployee", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        string taskname = txt_TaskName.Text;
        string Current = current.Text;
        string Replacer = replacer.Text;
        cmd.Parameters.Add(new SqlParameter("@taskname", taskname));
        cmd.Parameters.Add(new SqlParameter("@current", Current));
        cmd.Parameters.Add(new SqlParameter("@replacer", Replacer));

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";
        cmd.Parameters.Add(new SqlParameter("@manager", username));

        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;

        if (Current != "" & taskname != "" & Replacer != "")
        {

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (error.Value.Equals(0))
            {
                Response.Write("Assigned Employee is Changed");
            }
            else
            {
                Response.Write("one of your entries are wrong ");
            }
        }
        else
        {
            Response.Write("you should fill in all the Entries ");

        }
    }
}