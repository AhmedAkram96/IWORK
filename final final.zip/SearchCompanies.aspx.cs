﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class SearchCompanies : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
      

        if (Session["CompanySearch"].Equals("CompanyName"))
        {

            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("CompanyByName", conn);
            cmd.CommandType = CommandType.StoredProcedure;


            string Companyname = Session["Search_String"].ToString();

            cmd.Parameters.Add(new SqlParameter("@name", Companyname));
            SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
            error.Direction = ParameterDirection.Output;
            conn.Open();

         /*   SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            sda.Fill(dt);
            grid1.DataSource = dt;
            grid1.DataBind();*/

            SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
             while (rdr.Read())
            {
                string companyName = rdr.GetString(rdr.GetOrdinal("name"));

                Label lbl_CompanyName = new Label();
                form1.Controls.Add(lbl_CompanyName);
            }


        }


        else
        {
            if (Session["CompanySearch"].Equals("CompanyAddress"))
            {
                string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
                SqlConnection conn = new SqlConnection(connStr);

                SqlCommand cmd1 = new SqlCommand("CompanyByAddress", conn);
                cmd1.CommandType = CommandType.StoredProcedure;


                string Companyaddress = Session["Search_String"].ToString();

                cmd1.Parameters.Add(new SqlParameter("@address", Companyaddress));
                SqlParameter error = cmd1.Parameters.Add("@error", SqlDbType.Int);
                error.Direction = ParameterDirection.Output;
                //conn.Open();

                SqlDataAdapter sda = new SqlDataAdapter(cmd1);
                DataTable dt = new DataTable();

                sda.Fill(dt);
                grid1.DataSource = dt;
                grid1.DataBind();
            }
        }

    }





}