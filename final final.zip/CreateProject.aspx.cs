﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class CreateProject : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("ManagerProfile", true);

    }
    protected void Manager_Profile(object sender, EventArgs e)
    {

        Response.Redirect("ManagerProfile", true);

    }

    protected void create_project(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("CreateProject", conn);
        cmd.CommandType = CommandType.StoredProcedure;

      

        

            string projectname = txt_projectname.Text;

        //string companymail= Session["companymail"]
        string companymail = "main@shell.us";
            string startdate = txt_startdate.Text;
            string enddate = txt_enddate.Text;
            cmd.Parameters.Add(new SqlParameter("@projectName", projectname));
            cmd.Parameters.Add(new SqlParameter("@companyMail", companymail));
            cmd.Parameters.Add(new SqlParameter("@start_date", startdate));
            cmd.Parameters.Add(new SqlParameter("@end_date", enddate));

            // string username = Session["Username"].ToString();

            string username = "youssef.yasser";
            cmd.Parameters.Add(new SqlParameter("@managerName", username));

        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;




        if (projectname != ""  & startdate !="" & enddate != "")
        {

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (error.Value.Equals(0))
            {
                Response.Write("project created ! ");
            }
            else
            {
                Response.Write("one of your entries are wrong ");
            }
        }
        else
        {
            Response.Write("you should enter a project name and decide a start and end date");

        }
        }
       

    }
