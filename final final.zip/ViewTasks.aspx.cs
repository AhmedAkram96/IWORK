﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class ViewTasks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Accept(object sender, EventArgs e)
    {
        Button Button3 = (Button)sender;
        GridViewRow selectedRow = (GridViewRow)Button3.NamingContainer;
        string projectname = selectedRow.Cells[1].Text;
        string taskname = selectedRow.Cells[0].Text;
        string deadline = selectedRow.Cells[3].Text;


        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("spCheckFinishedTask", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";

        cmd.Parameters.Add(new SqlParameter("@manager", username));
        cmd.Parameters.Add(new SqlParameter("@acceptance", "1"));
        cmd.Parameters.Add(new SqlParameter("@deadline", deadline));
        cmd.Parameters.Add(new SqlParameter("@projectname", projectname));
        cmd.Parameters.Add(new SqlParameter("@taskname", taskname));

        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;

       
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (error.Value.Equals(0))
            {
                Response.Write("Task Accepted and is now closed ! ");
            }
            else
            {
                Response.Write("one of your entries are wrong ");
            }
        
       


    }
    protected void Reject(object sender, EventArgs e)
    {
        Button Button3 = (Button)sender;
        GridViewRow selectedRow = (GridViewRow)Button3.NamingContainer;
        string projectname = selectedRow.Cells[1].Text;
        string taskname = selectedRow.Cells[0].Text;
        string deadline = TextBox1.Text;


        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("spCheckFinishedTask", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";

        cmd.Parameters.Add(new SqlParameter("@manager", username));
        cmd.Parameters.Add(new SqlParameter("@acceptance", "0"));
        cmd.Parameters.Add(new SqlParameter("@deadline", deadline));
        cmd.Parameters.Add(new SqlParameter("@projectname", projectname));
        cmd.Parameters.Add(new SqlParameter("@taskname", taskname));

        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;

        if (deadline != "")
        {
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (error.Value.Equals(0))
            {
                Response.Write("Task Rejected and is re-assigned with new deadline ! ");
            }
            else
            {
                Response.Write("one of your entries are wrong ");
            }
        }
        else
        {
            Response.Write("you should Enter a new Deadline");
        }
    }

    protected void View(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("spViewTasks", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string Project = txt_projectname.Text;
        string Status = status.Text;
        cmd.Parameters.Add(new SqlParameter("@projectname", Project));
        cmd.Parameters.Add(new SqlParameter("@status", Status));
        //SqlParameter pass = cmd.Parameters.Add("@password", SqlDbType.VarChar, 50);
        //pass.Value = password;

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";
        cmd.Parameters.Add(new SqlParameter("@manager", username));


        // output parm
        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;

        if(Status=="fixed" || Status == "Fixed")
        {
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (error.Value.Equals(0))
            {
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                sda.Fill(dt);
                grid2.DataSource = dt;
                grid2.DataBind();

            }
            else
            {
                Response.Write("one of your entries are wrong ");
            }
        }
        else
        {
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (error.Value.Equals(0))
            {
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                sda.Fill(dt);
                grid1.DataSource = dt;
                grid1.DataBind();

            }
            else
            {
                Response.Write("one of your entries are wrong ");
            }
        }

    }


}