﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void category(object sender, EventArgs e)
    {
        Response.Redirect("NationalAndInter", true);
    }

    protected void login(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("Login", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string username = txt_username.Text;
        string password = txt_password.Text;
        cmd.Parameters.Add(new SqlParameter("@username", username));
        cmd.Parameters.Add(new SqlParameter("@password", password));
        //SqlParameter pass = cmd.Parameters.Add("@password", SqlDbType.VarChar, 50);
        //pass.Value = password;

        // output parm
        SqlParameter count = cmd.Parameters.Add("@userornot", SqlDbType.Int);
        count.Direction = ParameterDirection.Output;
        SqlParameter type = cmd.Parameters.Add("@type", SqlDbType.VarChar,50);
        type.Direction = ParameterDirection.Output;

        SqlParameter companymail = cmd.Parameters.Add("@companyMail", SqlDbType.VarChar, 50);
        companymail.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();

        Session["Username"] = username;
        Session["companymail"] = companymail;

            if (count.Value.ToString().Equals("1"))
                {
                    //this is how you store data to session variable.
                    Session["Username"] = username;
                    Response.Write("Passed");
                    if (type.Value.ToString().Equals("Manager"))
                    {
                        Response.Redirect("ManagerProfile", true);
                    }
                    else if(type.Value.ToString().Equals("HR employee"))
                    {
                        Response.Redirect("HRProfile", true);
                    }

                    else if (type.Value.ToString().Equals("Regular employee"))
                    {
                        Response.Redirect("RegularProfile", true);
                    }
                    else
                    {
                        Response.Redirect("JobSeekerProfile", true);
                    }

                }
                else
                {
                    Response.Write("Failed to login");

        }



    }

    protected void search(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);


        SqlCommand cmd = new SqlCommand("CompanyByName", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        SqlCommand cmd1 = new SqlCommand("CompanyByAddress", conn);
        cmd1.CommandType = CommandType.StoredProcedure;


        string search_string = search_text.Text.ToString();
        cmd.Parameters.Add(new SqlParameter("@name", search_string));
        cmd1.Parameters.Add(new SqlParameter("@address", search_string));
        //SqlParameter pass = cmd.Parameters.Add("@password", SqlDbType.VarChar, 50);
        //pass.Value = password;

        // output parm
        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;

        SqlParameter error1 = cmd1.Parameters.Add("@error", SqlDbType.Int);
        error1.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        cmd1.ExecuteNonQuery();
        conn.Close();
        Session["Search_String"] = search_string;
        Session["CompanySearch"] = "Default";
        if (error.Value.ToString().Equals("0"))
        {
            //this is how you store data to session variable.
           
            Session["CompanySearch"] = "CompanyName";
            Response.Redirect("SearchCompanies", true);
            
        }
        else
        {

            if (error1.Value.ToString().Equals("0"))
            {
                //this is how you store data to session variable.
                Response.Write("Passed");
                Session["CompanySearch"] = "CompanyAddress";
                Response.Redirect("SearchCompanies", true);
               
            }
            else
            {
                Response.Write("No results were found");
            }
        }
    }


}