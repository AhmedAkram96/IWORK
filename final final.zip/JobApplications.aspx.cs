﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class JobApplications : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("ShowJobAppp", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            // string username = Session["Username"].ToString();

            string username = "youssef.yasser";
            cmd.Parameters.Add(new SqlParameter("@manager", username));

            cmd.Connection = conn;
            conn.Open();
            Jobs.DataSource = cmd.ExecuteReader();
            Jobs.DataTextField = "Title";
            // ddlCustomers.DataValueField = "CustomerId";
            Jobs.DataBind();
            conn.Close();


            Jobs.Items.Insert(0, new ListItem("--Select Job--", "0"));

        }
    }

    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("ManagerProfile", true);

    }





    protected void AcceptApp(object sender, EventArgs e)
    {

        Button Button3 = (Button)sender;
        GridViewRow selectedRow = (GridViewRow)Button3.NamingContainer;
        string text = selectedRow.Cells[0].Text;
        Session["ApplicantforJob"] = text;



        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("spAccRejAppManager", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";

        // string company = Session["Company"].ToString();
        string company = "main@shell.us";

        //  string department = Session["Department"].ToString();
        int department = 1;

        cmd.Parameters.Add(new SqlParameter("@manager", username));
        cmd.Parameters.Add(new SqlParameter("@approval", "1"));
        cmd.Parameters.Add(new SqlParameter("@applicant", text));
        cmd.Parameters.Add(new SqlParameter("@company", company));
        cmd.Parameters.Add(new SqlParameter("@department", department));

        Response.Write(text + " " + "is accepted !");

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();


    }
    protected void RejectApp(object sender, EventArgs e)
    {

        Button Button3 = (Button)sender;
        GridViewRow selectedRow = (GridViewRow)Button3.NamingContainer;
        string text = selectedRow.Cells[0].Text;
        Session["ApplicantforJob"] = text;



        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("spAccRejAppManager", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";

        // string company = Session["Company"].ToString();
        string company = "main@shell.us";

        //  string department = Session["Department"].ToString();
        int department = 1;

        cmd.Parameters.Add(new SqlParameter("@manager", username));
        cmd.Parameters.Add(new SqlParameter("@approval", "0"));
        cmd.Parameters.Add(new SqlParameter("@applicant", text));
        cmd.Parameters.Add(new SqlParameter("@company", company));
        cmd.Parameters.Add(new SqlParameter("@department", department));

        Response.Write(text + " " + "is Rejected !");

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }


    protected void ViewApp(object sender, EventArgs e)
    {
        String temp = Jobs.SelectedItem.Value;

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("spViewAppManager", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        // string username = Session["Username"].ToString();

        string username = "youssef.yasser";
        cmd.Parameters.Add(new SqlParameter("@manager", username));
        cmd.Parameters.Add(new SqlParameter("@job", temp));
        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;

        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();

        sda.Fill(dt);
        GridView2.DataSource = dt;
        GridView2.DataBind();

        if (error.Value.Equals(1))
        {
            Response.Write("Choose a Job first");
        }

    }

  
    protected void grid1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void grid1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
}