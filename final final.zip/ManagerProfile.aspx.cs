﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class ManagerProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Refresh1(object sender, EventArgs e)
    {
        Response.Redirect("ManagerProfile", true);
    }
    protected void ViewTasks(object sender, EventArgs e)
    {
        Response.Redirect("ViewTasks", true);
    }
    protected void Assign_employees(object sender, EventArgs e)
    {
        Response.Redirect("AssignEmployees", true);

    }

    protected void Create_Project(object sender, EventArgs e)
    {
        Response.Redirect("CreateProject", true);
    }

    protected void Accept(object sender, EventArgs e)
    {

        Button Button3 = (Button)sender;
        GridViewRow selectedRow = (GridViewRow)Button3.NamingContainer;
        string text = selectedRow.Cells[1].Text;
        Session["Applicant"] = text;

        string text1 = selectedRow.Cells[0].Text;


        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("spAccRejRequests", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";
        String reason = "";
        cmd.Parameters.Add(new SqlParameter("@manager", username));
        cmd.Parameters.Add(new SqlParameter("@approval", "1"));
        cmd.Parameters.Add(new SqlParameter("@reason", reason));
        cmd.Parameters.Add(new SqlParameter("@applicant", text));
        cmd.Parameters.Add(new SqlParameter("@startdate", text1));

        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;


        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();

    /*    if (error.Value.ToString().Equals("1"))
        {
            Response.Write("you should enter a reason for rejection");
        }*/

    }
    protected void Reject(object sender, EventArgs e)
    {
        Button Button3 = (Button)sender;
        GridViewRow selectedRow = (GridViewRow)Button3.NamingContainer;
        string text = selectedRow.Cells[1].Text;
        Session["Applicant"] = text;

        string text1 = selectedRow.Cells[0].Text;


        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("spAccRejRequests", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        // string username = Session["Username"].ToString();
        string username = "youssef.yasser";

        string reason = txt_password.Text;

        cmd.Parameters.Add(new SqlParameter("@manager", username));
        cmd.Parameters.Add(new SqlParameter("@approval", "0"));
        cmd.Parameters.Add(new SqlParameter("@reason", reason));
        cmd.Parameters.Add(new SqlParameter("@applicant", text));
        cmd.Parameters.Add(new SqlParameter("@startdate", text1));  


        SqlParameter error = cmd.Parameters.Add("@error", SqlDbType.Int);
        error.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();

        if (reason=="")
        {
            Response.Write("you should enter a reason for rejection");
        }
    }

   

    protected void View(object sender, EventArgs e)
    {
        

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("spViewRequests", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        // string username = Session["Username"].ToString();

        string username = "youssef.yasser";
        cmd.Parameters.Add(new SqlParameter("@username", username));


        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();

        sda.Fill(dt);
        grid1.DataSource = dt;
        grid1.DataBind();

        


    }

    protected void RemoveEmployees(object sender, EventArgs e)
    {
        Response.Redirect("RemoveEmployees", true);

    }

    protected void JobProfile(object sender, EventArgs e)
    {
        Response.Redirect("JobApplications", true);
    }

    protected void AssignToTask1(object sender, EventArgs e)
    {
        Response.Redirect("AssignEmployeesToTask", true);
    }
    protected void DefineTask1(object sender, EventArgs e)
    {
        Response.Redirect("DefineTask", true);
    }


    protected void grid1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void grid1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
}